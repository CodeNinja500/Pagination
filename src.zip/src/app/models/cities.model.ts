export interface CitiesModel {
  readonly name: string;
  readonly id: string;
}
