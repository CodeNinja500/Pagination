export interface BeerModel {
  readonly id: string;
  readonly name: string;
}
