export interface ComfortFeatureModel {
  readonly name: string;
  readonly id: string;
}
