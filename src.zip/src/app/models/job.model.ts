export interface JobModel {
  readonly title: string;
  readonly description: string;
  readonly id: string;
}
